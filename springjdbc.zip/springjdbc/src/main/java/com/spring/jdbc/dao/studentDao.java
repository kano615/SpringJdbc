package com.spring.jdbc.dao;

import java.util.List;

import com.spring.jdbc.entities.Student; 

public interface studentDao {
	public int insert(Student student);
	public int uppdate(Student student);
	public int delete(int studentid);
	public Student  getstudent(int studentid);
	public List<Student> getallstudent();

}
