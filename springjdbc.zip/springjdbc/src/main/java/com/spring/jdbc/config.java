package com.spring.jdbc;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.spring.jdbc.dao.StudentDaoImpl;

@Configuration
public class config {
	
	public DriverManagerDataSource ds()
	{
		DriverManagerDataSource ds=new DriverManagerDataSource();
		ds.setDriverClassName("com.mysql.cj.jdbc.Driver");
		ds.setUrl("jdbc:mysql://localhost:3306/springjdbc");
		ds.setUsername("root");
		ds.setPassword("");
		return ds;
	}
	
	@Bean
	public JdbcTemplate jdbcTemplate()
	{
		JdbcTemplate jdbcTemplate=new JdbcTemplate();
		jdbcTemplate.setDataSource(ds());
		return jdbcTemplate;
	}
	
	@Bean("studentDao")
	public StudentDaoImpl studentDaoImpl()
	{
		StudentDaoImpl studentDaoImpl=new StudentDaoImpl();
		studentDaoImpl.setJdbcTemplate(jdbcTemplate());
		return studentDaoImpl;
	}

}
