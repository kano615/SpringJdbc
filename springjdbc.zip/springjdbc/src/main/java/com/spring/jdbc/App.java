package com.spring.jdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.spring.jdbc.dao.StudentDaoImpl;

import com.spring.jdbc.entities.Student;

public class App {
	private static ApplicationContext context;

	public static void main(String[] args) {
		System.out.println("my program Strated");

		context = new AnnotationConfigApplicationContext(config.class);
		StudentDaoImpl studentDaoImpl = context.getBean("studentDao", StudentDaoImpl.class);

		// insert record using Spring jdbc
//		Student student = new Student();
//		student.setId(3);
//		student.setName("demo3");
//		student.setCity("rajkot");
//		
//		int result = studentDaoImpl.insert(student);
//		System.out.println("student Added"+result);

		// update record using Spring jdbc

//		Student student =new Student();
//		student.setId(1);
//		student.setName("demo");
//		student.setCity("rajkot");
//		
//		int uppdate = studentDaoImpl.uppdate(student);
//		System.out.println("record updated   "+ uppdate);

		// delete record using spring jdbc

//		int delete = studentDaoImpl.delete(1);
//		System.out.println("record deleteed:"+1);

		// selct one student record

		Student getstudent = studentDaoImpl.getstudent(2);
		System.out.println(getstudent);
		
		// select Allrecord from student
		
//		List<Student> getallstudent = studentDaoImpl.getallstudent();
//		
//		for(Student s: getallstudent)
//		{
//			System.out.println(s);
//		}

	}
}
